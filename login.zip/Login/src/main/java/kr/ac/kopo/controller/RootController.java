package kr.ac.kopo.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/")
public class RootController {
		
		@RequestMapping("/")
		String index() {
			return "index";
		}
		
		@RequestMapping(value="/login", method=RequestMethod.GET)
		String login() {
			return "login";
		}
		@RequestMapping(value="/login", method=RequestMethod.POST)
		String login(String id, String password, HttpSession session) {
			if(id.equals("user") && password.equals("1234")) {
				session.setAttribute("user", "사용자");
			}else if(id.equals("admin") && password.equals("admin")) {
				session.setAttribute("admin", "운영자");
			}else {
				System.out.println("로그인 실패");
			}
			
			return "redirect:";
		}
		@RequestMapping("/logout")
		String logout(HttpSession session) {
			session.invalidate();
			
			return "redirect:";
		}
		@RequestMapping("/user")
		String user() {
			return "user";
		}
		@RequestMapping("/admin")
		String admin() {
			return "admin";
		}
}

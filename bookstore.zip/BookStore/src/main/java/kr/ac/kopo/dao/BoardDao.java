package kr.ac.kopo.dao;

import java.util.List;

import kr.ac.kopo.model.Pager;
import kr.ac.kopo.model.Post;

public interface BoardDao {

	List<Post> list(Pager pager);

	void add(Post item);

	Post item(int bid);

	void update(Post item);

	void delete(int bid);

}

package kr.ac.kopo.service;

import java.util.List;

import kr.ac.kopo.model.Book;

public interface BookService { //bookservice �� �������̽�

	List<Book> list();

	void add(Book item);

	void delete(int bookid);

	Book item(int bookid);

	void update(Book item);

}

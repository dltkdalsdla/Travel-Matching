package kr.ac.kopo.dao;

import java.util.List;

import kr.ac.kopo.model.Book;

public interface BookDao {

	List<Book> list();

	void add(Book item);

	void delete(int bookid);

	Book item(int bookid);

	void update(Book item);

}

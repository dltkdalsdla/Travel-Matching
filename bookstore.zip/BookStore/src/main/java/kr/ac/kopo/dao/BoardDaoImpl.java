package kr.ac.kopo.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.ac.kopo.model.Pager;
import kr.ac.kopo.model.Post;

@Repository
public class BoardDaoImpl implements BoardDao {
	
	@Autowired
	SqlSession sql;

	@Override
	public List<Post> list(Pager pager) {
		int total = sql.selectOne("board.total");
		
		pager.setTotal(total);

		return sql.selectList("board.list", pager);
	}

	@Override
	public void add(Post item) {
		sql.insert("board.add", item);
	}

	@Override
	public Post item(int bid) {
		return sql.selectOne("board.item", bid);
	}

	@Override
	public void update(Post item) {
		sql.update("board.update", item);
	}

	@Override
	public void delete(int bid) {
		sql.delete("board.delete", bid);
	}

}

package kr.ac.kopo.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.ac.kopo.model.Book;

@Repository("BookDaoOracle")
public class BookDaoOracle implements BookDao {
	
	@Autowired //sql�� ����
	SqlSession sql;

	@Override 
	public List<Book> list() { //book.list�� �����´�
		return sql.selectList("book.list");
	}

	@Override
	public void add(Book item) { 
		sql.insert("book.add", item);
	}

	@Override
	public void delete(int bookid) { 
		sql.delete("book.delete", bookid);
	}

	@Override
	public Book item(int bookid) { //book.item ���� bookid �ϳ��� ������
		return sql.selectOne("book.item", bookid);
	}

	@Override
	public void update(Book item) {
		sql.update("book.update", item);
	}
}

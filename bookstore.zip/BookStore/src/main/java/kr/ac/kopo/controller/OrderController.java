package kr.ac.kopo.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.ac.kopo.model.Book;
import kr.ac.kopo.model.Customer;
import kr.ac.kopo.model.Order;
import kr.ac.kopo.service.BookService;
import kr.ac.kopo.service.CustomerService;
import kr.ac.kopo.service.OrderService;

@Controller
@RequestMapping("/orders")
public class OrderController {
	final String path = "order/";
	
	@Autowired
	OrderService service;
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	BookService bookService;
	
	@InitBinder //��¥�� ����ȯ �ϱ����� ����
	private void dateBinder(WebDataBinder binder) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		
		CustomDateEditor editor = new CustomDateEditor(format, true);
		
		binder.registerCustomEditor(Date.class, editor);
	}
	
	@RequestMapping("/list")
	public String list(Model model) {
		List<Order> list = service.list();
		
		model.addAttribute("list", list);
		
		return path + "list";
	}
	
	@RequestMapping(value="/add", method=RequestMethod.GET)
	public String add(Model model) {
		List<Book> books = bookService.list();	//BookService, CustomerService�� list�� books, customers��� ���ο� list�� ����  	
		List<Customer> customers = customerService.list();
		
		model.addAttribute("books", books);
		model.addAttribute("customers", customers);
		
		return path + "add";
	}
	
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public String add(Order item) {
		service.add(item);
		
		return "redirect:list";
	}

	@RequestMapping(value="/update", method=RequestMethod.GET)
	public String update(int orderid, Model model) {
		Order item = service.item(orderid);
		
		model.addAttribute("item", item);
		
		List<Book> books = bookService.list();		
		List<Customer> customers = customerService.list();
		
		model.addAttribute("books", books);
		model.addAttribute("customers", customers);
		
		return path + "update";
	}
	
	@RequestMapping(value="/update", method=RequestMethod.POST)
	public String update(Order item) {
		service.update(item);
		
		return "redirect:list";
	}
	
	@RequestMapping("/delete")
	public String delete(int orderid) {
		service.delete(orderid);
		
		return "redirect:list";
	}
}

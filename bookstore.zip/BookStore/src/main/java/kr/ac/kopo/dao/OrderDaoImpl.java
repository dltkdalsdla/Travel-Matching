package kr.ac.kopo.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.ac.kopo.model.Order;

@Repository
public class OrderDaoImpl implements OrderDao {
	
	@Autowired
	SqlSession sql;

	@Override
	public List<Order> list() {
		return sql.selectList("order.list");
	}

	@Override
	public void add(Order item) {
		sql.insert("order.add", item);
	}

	@Override
	public Order item(int orderid) {
		return sql.selectOne("order.item", orderid);
	}

	@Override
	public void update(Order item) {
		sql.update("order.update", item);
	}

	@Override
	public void delete(int orderid) {
		sql.delete("order.delete", orderid);
	}

}

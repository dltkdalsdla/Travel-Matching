package kr.ac.kopo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.kopo.dao.OrderDao;
import kr.ac.kopo.model.Order;

@Service
public class OrderServiceImpl implements OrderService {
	
	@Autowired
	OrderDao dao;

	@Override
	public List<Order> list() {
		return dao.list();
	}

	@Override
	public void add(Order item) {
		dao.add(item);
	}

	@Override
	public Order item(int orderid) {
		return dao.item(orderid);
	}

	@Override
	public void update(Order item) {
		dao.update(item);
	}

	@Override
	public void delete(int orderid) {
		dao.delete(orderid);
	}

}

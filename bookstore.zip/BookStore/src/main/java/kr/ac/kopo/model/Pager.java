package kr.ac.kopo.model;

public class Pager {
	float total;

	int page = 1;
	int perPage = 10;
	
	public String getPagination() {		
		String html = "<div class=\"pagination pagination-sm\">";//pagenation html�� ����
		
		int maxPage = (int) Math.ceil( total / perPage );
		for(int i=1; i <= maxPage; i++) {
			html += "<span class=\"page-item\"><a class=\"page-link\" href=\"?page=" + i + "\">" + i + "</a></span>";
		}
		
		html += "</div>";
		
		return html;
	}

	public float getTotal() {
		return total;
	}

	public void setTotal(float total) {
		this.total = total;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getPerPage() {
		return perPage;
	}

	public void setPerPage(int perPage) {
		this.perPage = perPage;
	}
}

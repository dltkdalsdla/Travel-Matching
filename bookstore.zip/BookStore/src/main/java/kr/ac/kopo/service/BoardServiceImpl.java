package kr.ac.kopo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.kopo.dao.BoardDao;
import kr.ac.kopo.model.Pager;
import kr.ac.kopo.model.Post;

@Service
public class BoardServiceImpl implements BoardService {
	
	@Autowired
	BoardDao dao;

	@Override
	public List<Post> list(Pager pager) {
		return dao.list(pager);
	}

	@Override
	public void add(Post item) {
		dao.add(item);		
	}

	@Override
	public Post item(int bid) {
		return dao.item(bid);
	}

	@Override
	public void update(Post item) {
		dao.update(item);
	}

	@Override
	public void delete(int bid) {
		dao.delete(bid);
	}

}

package kr.ac.kopo.dao;

import java.util.List;

import kr.ac.kopo.model.Order;

public interface OrderDao {

	List<Order> list();

	void add(Order item);

	Order item(int orderid);

	void update(Order item);

	void delete(int orderid);

}

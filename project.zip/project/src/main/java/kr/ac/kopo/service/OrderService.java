package kr.ac.kopo.service;

import java.util.List;

import kr.ac.kopo.model.Order;

public interface OrderService {

	List<Order> list();

	void add(Order item);

	Order item(int orderid);

	void update(Order item);

	void delete(int orderid);

}

package kr.ac.kopo.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import kr.ac.kopo.model.Book;

@Repository("BookDaoImpl") //dao 클래스 임을 나타내는 어노테이션
public class BookDaoImpl implements BookDao {
	ArrayList<Book> list; //Book으로 list 생성   
	
	public BookDaoImpl() { 
		list = new ArrayList<Book>(); 
		
		Book item = new Book();
		item.setBookid(1);
		item.setBookname("");
		item.setPublisher("�뤃由ы뀓");
		item.setPrice(2000);
		list.add(item);
		
		item = new Book();
		item.setBookid(2);
		item.setBookname("�뜲�씠�꽣踰좎씠�뒪");
		item.setPublisher("�븳鍮쏅�몃뵒�뼱");
		item.setPrice(3500);
		list.add(item);
	}

	@Override
	public List<Book> list() {
		return list;
	}

	@Override
	public void add(Book item) {
		list.add(item);		
	}

	@Override
	public void delete(int bookid) { 
 		for(Book item : list) {  //Book의 item을 list와 비교 만약 item의 bookid와 list의 bookid가 같다면 list에서 item 삭제
			if(item.getBookid() ==  bookid) {
				list.remove(item);
				break;
			}
		}
	}

	@Override
	public Book item(int bookid) {
		for(Book item : list) { //Book의 item을 list와 비교해서 item의 bookid 와 list의 bookid가 같다면 item으로 반환
			if(item.getBookid() ==  bookid) {
				return item;
			}
		}
		
		return null;
	}

	@Override
	public void update(Book item) {
		for(Book book : list) { //Book의 book을 list와 비교해서 book의 bookid와 item의 bookid가 같다면 item의 bookname, publisher, price를 각각 book의 값에 대입
			if(book.getBookid() == item.getBookid()) {
				book.setBookname(item.getBookname());
				book.setPublisher(item.getPublisher());
				book.setPrice(item.getPrice());
				
				break;
			}
		}
	}

}
